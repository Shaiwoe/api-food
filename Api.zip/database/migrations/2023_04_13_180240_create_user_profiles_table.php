<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('user_profiles', function (Blueprint $table) {

            $table->id();

            $table->foreignId('user_id');

            $table->string('name');
            $table->string('national');
            $table->string('phone');
            $table->string('cellphone');
            $table->string('email');
            $table->string('address');
            $table->string('shop_name');
            $table->string('shop_type');
            $table->string('shop_phone');
            $table->string('shop_city');
            $table->string('shop_address');

            $table->string('bank_sheba');
            $table->string('bank_name');

            $table->string('zip_url');

            $table->string('status');

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('user_profiles');
    }
};
