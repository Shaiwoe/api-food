<?php

return [
    'merchant' => 'zibal',
    'purchase' => 'https://gateway.zibal.ir/v1/request',
    'complete' => 'https://gateway.zibal.ir/v1/verify',
];
