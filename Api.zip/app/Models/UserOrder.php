<?php

namespace App\Models;

class UserOrder extends BaseModel
{
}
