<?php

namespace App\Models;

class UserProfile extends BaseModel
{
}
