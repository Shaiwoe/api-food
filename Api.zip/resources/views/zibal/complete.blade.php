Pay completed
